from django.urls import path,include
from workspaces.FirstApp.views import TodoListView,TodoDetailView

app_name="FirstApp"

urlpatterns = [
    path("api/todos/", include("workspaces.FirstApp.urls")),  # Includes FirstApp's URL patterns
    # path("platform/", include("zango.config.urls_platform")),
    path("api/patients/", include('workspaces.SecondApp.urls')),
    path("api/students/", include('workspaces.ThirdApp.urls')),
    path("^", include("zango.config.urls_public")),

]
