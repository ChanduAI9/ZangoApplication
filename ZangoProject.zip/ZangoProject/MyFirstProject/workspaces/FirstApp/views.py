from django.shortcuts import render, get_object_or_404, redirect
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import Todo
from .serializers import TodoSerializer


class TodoListView(APIView):
    """
    Handles listing all todos.
    """
    def get(self, request):
        todos = Todo.objects.all()
        return render(request, "todo_list.html", {"todos": todos})


class AddTodoView(APIView):
    """
    Handles adding a new todo.
    """
    def get(self, request):
        return render(request, "add_todo.html")

    def post(self, request):
        title = request.POST.get("title")
        description = request.POST.get("description")
        is_completed = request.POST.get("is_completed") == "on"

        Todo.objects.create(title=title, description=description, is_completed=is_completed)
        return redirect("FirstApp:todo_list")


class UpdateTodoView(APIView):
    """
    Handles updating an existing todo.
    """
    def get(self, request, pk):
        todo = get_object_or_404(Todo, pk=pk)
        return render(request, "update_todo.html", {"todo": todo})

    def post(self, request, pk):
        todo = get_object_or_404(Todo, pk=pk)
        todo.title = request.POST.get("title")
        todo.description = request.POST.get("description")
        todo.is_completed = request.POST.get("is_completed") == "on"
        todo.save()
        return redirect("FirstApp:todo_list")


class DeleteTodoView(APIView):
    """
    Handles deleting an existing todo.
    """
    def get(self, request, pk):
        todo = get_object_or_404(Todo, pk=pk)
        return render(request, "delete_todo.html", {"todo": todo})

    def post(self, request, pk):
        todo = get_object_or_404(Todo, pk=pk)
        todo.delete()
        return redirect("FirstApp:todo_list")


class TodoDetailView(APIView):
    """
    Handles displaying details of a single todo.
    """
    def get(self, request, pk):
        todo = get_object_or_404(Todo, pk=pk)
        serializer = TodoSerializer(todo)
        return Response(serializer.data)
