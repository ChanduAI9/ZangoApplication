from django.apps import AppConfig

class FirstAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'workspaces.FirstApp'  # The full Python path to the app
    label = 'FirstApp'  # Explicit app label to ensure consistency
