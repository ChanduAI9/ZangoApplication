from django.db import models
import uuid

class Todo(models.Model):
    object_uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)  # Unique identifier
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True, null=True)
    is_completed = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table="FirstApp_todo"
        app_label="workspaces.FirstApp"