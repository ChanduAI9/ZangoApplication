from django.urls import path
from .views import TodoListView, TodoDetailView, AddTodoView, UpdateTodoView, DeleteTodoView

app_name = "FirstApp"  # Namespace for the app

urlpatterns = [
    path("", TodoListView.as_view(), name="todo_list"),  # List all todos
    path("add/", AddTodoView.as_view(), name="add_todo"),  # Add a new todo
    path("<int:pk>/update/", UpdateTodoView.as_view(), name="update_todo"),  # Update a todo
    path("<int:pk>/delete/", DeleteTodoView.as_view(), name="delete_todo"),  # Delete a todo
    path("<int:pk>/", TodoDetailView.as_view(), name="todo_detail"),  # View details of a single todo
]
