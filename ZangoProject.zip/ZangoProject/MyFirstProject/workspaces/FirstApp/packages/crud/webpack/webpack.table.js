import "../frontend/table.js";
