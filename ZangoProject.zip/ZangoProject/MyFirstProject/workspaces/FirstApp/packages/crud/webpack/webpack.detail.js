import "../frontend/detail.js";
