from rest_framework import serializers
from .models import Todo

class TodoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Todo
        fields = ['id', 'title', 'description', 'is_completed', 'created_at', 'updated_at']  # Explicit fields
        read_only_fields = ['created_at', 'updated_at']  # Read-only fields

    def validate_title(self, value):
        if not value.strip():
            raise serializers.ValidationError("Title cannot be empty.")
        return value

    def validate(self, data):
        if data['is_completed'] and not data['description']:
            raise serializers.ValidationError("Completed tasks must have a description.")
        return data
