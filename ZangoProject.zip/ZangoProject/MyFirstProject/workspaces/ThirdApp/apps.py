from django.apps import AppConfig


class StudentManagementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'workspaces.ThirdApp'  # Full dotted path to the app
    verbose_name = 'Student Management System'  # Human-readable name for the app
