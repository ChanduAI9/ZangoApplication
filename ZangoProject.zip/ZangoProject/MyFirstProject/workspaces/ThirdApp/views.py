from django.shortcuts import render, get_object_or_404, redirect
from django.urls import reverse
from django.views import View  # Correct import for View
from .models import Student
from .forms import StudentForm
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .serializers import StudentSerializer


class StudentListView(APIView):
    """
    List all students or render the student list template.
    """
    def get(self, request):
        students = Student.objects.all()
        # serializer = StudentSerializer(students, many=True)
        return render(request, "student_list.html", {"students": students})


class StudentCreateView(APIView):
    """
    Create a new student or render the student creation form.
    """
    def get(self, request):
        form = StudentForm()
        return render(request, "student_form.html", {"form": form})

    def post(self, request):
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("ThirdApp:student-list")
        return render(request, "student_form.html", {"form": form})


class StudentDetailView(APIView):
    """
    Retrieve details of a student and render the detail page.
    """
    def get(self, request, pk):
        student = get_object_or_404(Student, pk=pk)
        serializer = StudentSerializer(student)
        return render(request, "student_detail.html", {"student": serializer.data})


class StudentUpdateView(View):
    """
    Handles updating an existing student.
    """
    def get(self, request, pk):
        student = get_object_or_404(Student, pk=pk)
        form = StudentForm(instance=student)
        return render(request, 'student_form.html', {'form': form, 'student': student})

    def post(self, request, pk):
        student = get_object_or_404(Student, pk=pk)
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
            return redirect(reverse('ThirdApp:student-list'))
        return render(request, 'student_form.html', {'form': form, 'student': student})


class StudentDetailView(View):
    """
    Displays detailed information about a student and allows editing.
    """
    def get(self, request, pk):
        student = get_object_or_404(Student, pk=pk)
        return render(request, "student_detail.html", {"student": student})

    def post(self, request, pk):
        student = get_object_or_404(Student, pk=pk)
        student.delete()
        return redirect("ThirdApp:student-list")


class StudentDeleteView(View):
    """
    Handles deleting a student record.
    """
    def get(self, request, pk):
        student = get_object_or_404(Student, pk=pk)
        return render(request, 'student_confirm_delete.html', {'student': student})

    def post(self, request, pk):
        student = get_object_or_404(Student, pk=pk)
        student.delete()
        return redirect(reverse('ThirdApp:student-list'))
