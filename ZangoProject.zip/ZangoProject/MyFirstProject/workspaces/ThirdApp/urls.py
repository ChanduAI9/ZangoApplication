from django.urls import path
from .views import (
    StudentListView,
    StudentCreateView,
    StudentDetailView,
    StudentUpdateView,  # Add this
    StudentDeleteView,
)

app_name = 'ThirdApp'

urlpatterns = [
    path('', StudentListView.as_view(), name='student-list'),
    path('add/', StudentCreateView.as_view(), name='student-add'),
    path('<int:pk>/', StudentDetailView.as_view(), name='student-detail'),
    path('<int:pk>/edit/', StudentUpdateView.as_view(), name='student-edit'),  # Use StudentUpdateView
    path('<int:pk>/delete/', StudentDeleteView.as_view(), name='student-delete'),
]
