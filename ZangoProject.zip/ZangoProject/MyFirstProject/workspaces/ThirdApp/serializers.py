from rest_framework import serializers
from .models import Student

class StudentSerializer(serializers.ModelSerializer):
    name = serializers.SerializerMethodField()

    class Meta:
        model = Student
        fields = ['id', 'name', 'email', 'phone_number', 'address', 'date_of_birth', 'enrolled_at', 'updated_at']

    def get_name(self, obj):
        return f"{obj.first_name} {obj.last_name}"
