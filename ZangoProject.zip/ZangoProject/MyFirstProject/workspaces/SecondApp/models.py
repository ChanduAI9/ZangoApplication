from django.db import models

class Patient(models.Model):
    name = models.CharField(max_length=255)
    age = models.IntegerField()
    address = models.TextField(blank=True, null=True)
    contact_number = models.CharField(max_length=15, blank=True, null=True)
    disease = models.TextField(blank=True, null=True)
    medical_history = models.TextField(blank=True, null=True)
    assigned_doctor = models.CharField(max_length=255, blank=True, null=True)
    admitted_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "SecondApp_patient"
        app_label = "workspaces.SecondApp"
