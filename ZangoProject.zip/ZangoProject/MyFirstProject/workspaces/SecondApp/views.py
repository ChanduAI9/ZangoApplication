from django.shortcuts import render, get_object_or_404, redirect
from django.urls import reverse, reverse_lazy
from django.views import View
from .models import Patient
from .serializers import PatientSerializer
from .forms import PatientForm
from django.db.models import Count
from django.http import JsonResponse


class DashboardView(View):
    """
    Dashboard with patient statistics and recent activity.
    """
    def get(self, request):
        total_patients = Patient.objects.count()
        admitted_patients = Patient.objects.filter(disease__isnull=False).count()
        discharged_patients = total_patients - admitted_patients

        # Recent Patients
        recent_patients = Patient.objects.order_by('-admitted_at')[:5]

        return render(request, "dashboard.html", {
            "total_patients": total_patients,
            "admitted_patients": admitted_patients,
            "discharged_patients": discharged_patients,
            "recent_patients": recent_patients,
        })


class PatientListView(View):
    """
    List all patients with filtering and sorting options.
    """
    def get(self, request):
        sort_by = request.GET.get("sort_by", "name")  # Default sort by name
        query = request.GET.get("query", "")  # Search by name or disease
        patients = Patient.objects.filter(name__icontains=query).order_by(sort_by)
        serializer = PatientSerializer(patients, many=True)
        return render(request, "patient_list.html", {"patients": serializer.data, "query": query, "sort_by": sort_by})


class PatientCreateView(View):
    """
    Create a new patient.
    """
    def get(self, request):
        form = PatientForm()
        return render(request, "patient_form.html", {"form": form})

    def post(self, request):
        form = PatientForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect(reverse("SecondApp:patient-list"))
        return render(request, "patient_form.html", {"form": form})


class PatientDetailView(View):
    """
    Retrieve details of a specific patient.
    """
    def get(self, request, pk):
        patient = get_object_or_404(Patient, pk=pk)
        serializer = PatientSerializer(patient)
        return render(request, "patient_detail.html", {"patient": serializer.data})


class PatientUpdateView(View):
    """
    Update a patient's details.
    """
    def get(self, request, pk):
        patient = get_object_or_404(Patient, pk=pk)
        form = PatientForm(instance=patient)
        return render(request, "patient_form.html", {"form": form, "patient": patient})

    def post(self, request, pk):
        patient = get_object_or_404(Patient, pk=pk)
        form = PatientForm(request.POST, instance=patient)
        if form.is_valid():
            form.save()
            return redirect(reverse("SecondApp:patient-list"))
        return render(request, "patient_form.html", {"form": form, "patient": patient})


class PatientDeleteView(View):
    """
    Delete a patient's record.
    """
    def get(self, request, pk):
        patient = get_object_or_404(Patient, pk=pk)
        return render(request, "patient_confirm_delete.html", {"patient": patient})

    def post(self, request, pk):
        patient = get_object_or_404(Patient, pk=pk)
        patient.delete()
        return redirect(reverse("SecondApp:patient-list"))


class PatientStatisticsView(View):
    """
    API view for patient statistics (JSON response).
    """
    def get(self, request):
        total_patients = Patient.objects.count()
        admitted_patients = Patient.objects.filter(disease__isnull=False).count()
        discharged_patients = total_patients - admitted_patients

        return JsonResponse({
            "total_patients": total_patients,
            "admitted_patients": admitted_patients,
            "discharged_patients": discharged_patients,
        })
