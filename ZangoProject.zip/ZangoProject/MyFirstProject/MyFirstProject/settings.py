from pathlib import Path

from zango.config.settings.base import *

BASE_DIR = Path(__file__).resolve().parent.parent


class AttrDict(dict):
    """
    A dictionary subclass for managing global settings with attribute-style access.

    This class allows getting and setting items in the global namespace
    using both attribute and item notation.
    """

    def __getattr__(self, item):
        return globals()[item]

    def __setattr__(self, item, value):
        globals()[item] = value

    def __setitem__(self, key, value):
        globals()[key] = value


# Call setup_settings to initialize the settings
settings_result = setup_settings(AttrDict(vars()), BASE_DIR)

# Setting Overrides
# Any settings that need to be overridden or added should be done below this line
# to ensure they take effect after the initial setup

SECRET_KEY = "django-insecure-0^u^67acce9!73uroy0%g#b8pnepr7(gu3v-c52&vi0!6^cfpj"  # Shift this to .env


# To change the media storage to S3 you can use the BACKEND class provided by the default storage
# To change the static storage to S3 you can use the BACKEND class provided by the staticfiles storage
# STORAGES = {
#     "default": {"BACKEND": "zango.core.storage_utils.S3MediaStorage"},
#     "staticfiles": {"BACKEND": "zango.core.storage_utils.S3StaticStorage"},
# }


# INTERNAL_IPS can contain a list of IP addresses or CIDR blocks that are considered internal.
# Both individual IP addresses and CIDR notation (e.g., '192.168.1.1' or '192.168.1.0/24') can be provided.

DATABASES = {
    'default': {
        'ENGINE': 'django_tenants.postgresql_backend',
        'NAME': 'test11',
        'USER': 'postgres',
        'PASSWORD': '1229',
        'HOST': 'localhost',
        'PORT': '5432',
    }
}

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [
            Path(BASE_DIR) / "workspaces" / "FirstApp" / "templates",
        ],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]



INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "zango.apps.dynamic_models",
    "zango.apps.object_store",
    "zango.apps.auditlogs",
    "zango.apps.permissions",
    "zango.apps.appauth",
    "zango.apps.shared.tenancy",
    "zango.apps.shared.platformauth",
    "axes",
    "knox",
    "crispy_forms",
    "django_celery_results",
    "django_celery_beat",
    "zango.apps.tasks",
    "session_security",
    "django_extensions",
    # "FirstApp",
    "workspaces.FirstApp",
    "rest_framework",
]


MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "axes.middleware.AxesMiddleware",
    # "zango.apps.shared.tenancy.middleware.TenantMiddleware",
    # "zango.apps.shared.platformauth.middleware.PlatformAuthMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

CRISPY_TEMPLATE_PACK = "bootstrap4"
PUBLIC_SCHEMA_NAME = "public"
ROOT_URLCONF = 'zango.config.urls_public'
DEBUG =True

ROOT_URLCONF = "MyProject8.urls_public"

from pathlib import Path
import sys
from zango.config.settings.base import *

BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.append(str(BASE_DIR / "workspaces"))

class AttrDict(dict):
    """
    A dictionary subclass for managing global settings with attribute-style access.

    This class allows getting and setting items in the global namespace
    using both attribute and item notation.
    """

    def __getattr__(self, item):
        return globals()[item]

    def __setattr__(self, item, value):
        globals()[item] = value

    def __setitem__(self, key, value):
        globals()[key] = value


# Call setup_settings to initialize the settings
settings_result = setup_settings(AttrDict(vars()), BASE_DIR)

# Setting Overrides
# Any settings that need to be overridden or added should be done below this line
# to ensure they take effect after the initial setup

SECRET_KEY = "django-insecure-e2)*lubpgn1zz=5y1kfb)-()!($mhrtr=*(^ep!dv06xts99vl"  # Shift this to .env


# To change the media storage to S3 you can use the BACKEND class provided by the default storage
# To change the static storage to S3 you can use the BACKEND class provided by the staticfiles storage
# STORAGES = {
#     "default": {"BACKEND": "zango.core.storage_utils.S3MediaStorage"},
#     "staticfiles": {"BACKEND": "zango.core.storage_utils.S3StaticStorage"},
# }


# INTERNAL_IPS can contain a list of IP addresses or CIDR blocks that are considered internal.
# Both individual IP addresses and CIDR notation (e.g., '192.168.1.1' or '192.168.1.0/24') can be provided.

DATABASES = {
    'default': {
        'ENGINE': 'django_tenants.postgresql_backend',
        'NAME': 'test11',
        'USER': 'postgres',
        'PASSWORD': '1229',
        'HOST': 'localhost',
        'PORT': '5432',
    }
}


TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [
            Path(BASE_DIR) / "workspaces" / "FirstApp" / "templates",  # FirstApp templates
            Path(BASE_DIR) / "workspaces" / "SecondApp" / "templates",  # SecondApp templates
            Path(BASE_DIR) / "workspaces" / "ThirdApp" / "templates",  # ThirdApp templates
        ],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]



DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"


CELERY_RESULT_BACKEND = "django-db"
CELERY_CACHE_BACKEND = "django-cache"

# ROOT_URLCONF = "MyProject8.urls_public"

ROOT_URLCONF = "my_test_urls"

CRISPY_TEMPLATE_PACK = "bootstrap4"
PUBLIC_SCHEMA_NAME = "public"
# ROOT_URLCONF = 'zango.config.urls_public'
DEBUG =True


CELERY_RESULT_BACKEND = "django-db"
CELERY_CACHE_BACKEND = "django-cache"

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"


INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "zango.apps.dynamic_models",
    "zango.apps.object_store",
    "zango.apps.auditlogs",
    "zango.apps.permissions",
    "zango.apps.appauth",
    "zango.apps.shared.tenancy",
    "zango.apps.shared.platformauth",
    "axes",
    "knox",
    "crispy_forms",
    "django_celery_results",
    "django_celery_beat",
    "zango.apps.tasks",
    "session_security",
    "django_extensions",
    # "FirstApp",
    "workspaces.FirstApp",
    "workspaces.SecondApp",
    "workspaces.ThirdApp",
    "rest_framework",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "axes.middleware.AxesMiddleware",
    # "zango.apps.shared.tenancy.middleware.TenantMiddleware",
    # "zango.apps.shared.platformauth.middleware.PlatformAuthMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

# STATIC_URL = '/static/'
# STATICFILES_DIRS = [BASE_DIR / "static"]  # Ensure this is correct
